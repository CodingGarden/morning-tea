<template>
<div id="BJlbyq23pz">
  <mdc-drawer class="S1NzQq32pM" open toolbar-spacer persistent toggle-on="toggledrawer">
    <mdc-drawer-list class="HySzQqhhpz">
      <mdc-drawer-item class="H18f7q336G" start-icon="inbox">Inbox</mdc-drawer-item>
    
      <mdc-drawer-item class="HyDzQcn2TG" start-icon="send">Sent Mail</mdc-drawer-item>
    
      <mdc-drawer-item class="BJuMXc3npG" start-icon="drafts">Drafts</mdc-drawer-item>
    </mdc-drawer-list>
  </mdc-drawer>
  <mdc-drawer class="H1mXqh3pz" open toolbar-spacer persistent toggle-on="toggledrawer">
    <mdc-drawer-list class="S1emQ523aG">
      <mdc-drawer-item class="rkb7X522aG" start-icon="inbox">Inbox</mdc-drawer-item>
    
      <mdc-drawer-item class="r1G7m5nh6f" start-icon="send">Sent Mail</mdc-drawer-item>
    
      <mdc-drawer-item class="SJQQXq2nTG" start-icon="drafts">Drafts</mdc-drawer-item>
    </mdc-drawer-list>
  </mdc-drawer>
  <mdc-top-app-bar class="r1G37q236M" title="My App" event="toggledrawer">
    <mdc-top-app-bar-action class="ryX3m523TM" icon="help"></mdc-top-app-bar-action>
  
    <mdc-top-app-bar-action class="r1V3m5hnaM" icon="file_download"></mdc-top-app-bar-action>
  </mdc-top-app-bar>
  <mdc-list class="ByXxVq3haz" bordered>
    <mdc-list-item class="Sk4lEc2nTM">List item A</mdc-list-item>
  
    <mdc-list-item class="BJrxVchnTM">List item B</mdc-list-item>
  
    <mdc-list-item class="Hy8eV532pG">List item C</mdc-list-item>
  </mdc-list>
  <img class="SkKHq226z" src="/static/vuegg-fam.svg"/>
</div>
</template>

<script>
export default {
  name: 'home'
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
#BJlbyq23pz {
  --mdc-theme-primary: #673ab7;
  --mdc-theme-secondary: #f44336;
  --mdc-theme-background: #ffffff;
  position: relative;
  margin: auto;
  background-color: #ffffff;
  overflow: hidden;
  width: 100%;
  height: 100%;
}

.ByXxVq3haz {
  overflow: hidden;
  position: absolute;
  width: 1314px;
  height: 161px;
  top: 54px;
  left: 232px;
}

</style>
